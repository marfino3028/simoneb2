<?php

namespace App\Http\Livewire\Laporan;

use Livewire\Component;

class Create extends Component
{
    public function render()
    {
        return view('livewire.laporan.create');
    }
}
