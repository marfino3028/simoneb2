# Akun
### Admin
Arroisy.ys@gmail.com
admin


### Mahasiswa
marfinohamzah455@gmail.com
admin
valeniatp@gmail.com
admin


akses shell SSH menggunakan putty dan winscp utk transfer file:
host : vps.sebi.ac.id
port : 2607
username : marfino
password  :     nQS>P8h6
di /var/www/simoneb
di var/www/sido