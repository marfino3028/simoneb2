<?php if(Auth::user()->role == 'mahasiswa'): ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navigation-dropdown')->html();
} elseif ($_instance->childHasBeenRendered('R2kLkRa')) {
    $componentId = $_instance->getRenderedChildComponentId('R2kLkRa');
    $componentTag = $_instance->getRenderedChildComponentTagName('R2kLkRa');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('R2kLkRa');
} else {
    $response = \Livewire\Livewire::mount('navigation-dropdown');
    $html = $response->html();
    $_instance->logRenderedChild('R2kLkRa', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">                
                <h1 class="text-green-700 text-lg">Hai, <?php echo e(Auth::user()->name); ?> Sang Juara Selamat Datang Di Web Sistem Monitoring Laporan Beasiswa</h1>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php else: ?>

<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">                
                <h1 class="text-green-700 text-lg">Hai Admin <?php echo e(Auth::user()->name); ?> , Selamat Datang Di Web Sistem Monitoring Laporan Beasiswa</h1>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>

                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                                                    this.closest(\'form\').submit();']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                                                    this.closest(\'form\').submit();']); ?>
                        <?php echo e(__('Logout')); ?>

                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </form>
                <br>
                <table class="table-fixed w-full">

                    <thead>
                        <tr class="bg-gray-100">
                            <th class="px-4 py-2 w-25">Nama</th>
                            
                            <th class="px-4 py-2 w-25">Foto</th>
                            <th class="px-4 py-2 w-25">NIM</th>
                            <th class="px-4 py-2 w-25">Angkatan</th>
                            <th class="px-4 py-2 w-25">Alamat</th>
                            <th class="px-4 py-2 w-25">HP</th>
                            <th class="px-4 py-2 w-25">Beasiswa</th>
                            <th class="px-4 py-2 w-25">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="border px-4 py-2"><?php echo e($row->name); ?></td>
                                
                                <td class="border px-4 py-2"><img  src="<?php echo e($row->profile_photo_url); ?> " id="myImg" alt="<?php echo e($row->name); ?>"></td>
                                <td class="border px-4 py-2"><?php echo e($row->nim); ?></td>
                                <td class="border px-4 py-2"><?php echo e($row->angkatan); ?></td>
                                <td class="border px-4 py-2"><?php echo e($row->alamat); ?></td>
                                <td class="border px-4 py-2"><?php echo e($row->hp); ?></td>
                                <td class="border px-4 py-2"><?php echo e($row->beasiswa); ?></td>
                                <td class="border px-4 py-2">
                                    <div class="vx-row mb-6">
                                    <div class="vx-col sm:w-1/2 w-full">
                                    <button wire:click="view(<?php echo e($row->id); ?>)" class="bg-blue-500 hover:bg-blue-700 text-black font-bold py-2 px-4 rounded">Lihat</button>
                                    </div>
                                    <div class="vx-col sm:w-1/2 w-full">
                                    <button wire:click="delete(<?php echo e($row->id); ?>)" class="mt-6 bg-red-500 hover:bg-red-700 text-black font-bold py-2 px-4 rounded">Hapus</button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="border px-4 py-2 text-center" colspan="5">Tidak ada data</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sebi\simoneb2\resources\views/dashboard.blade.php ENDPATH**/ ?>