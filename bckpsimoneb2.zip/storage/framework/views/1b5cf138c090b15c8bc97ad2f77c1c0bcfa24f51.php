
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('STEI SEBI', 'STEI SEBI')); ?></title>
        <link rel="icon" href="<?php echo e(asset('logo.ico')); ?>"/>
        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">
        <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
        <script src="<?php echo e(asset('js/modal.js')); ?>" defer></script>
        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
        <?php echo \Livewire\Livewire::styles(); ?>

		
        <!-- Scripts -->
        <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.7.3/dist/alpine.js" defer></script>
		<?php echo \Livewire\Livewire::scripts(); ?>

    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen bg-gray-100">
            <?php if(Auth::user()->role == 'mahasiswa'): ?>
			<?php if(!request()->routeIs('dashboard')): ?>
				<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navigation-dropdown')->html();
} elseif ($_instance->childHasBeenRendered('2X4Fz3B')) {
    $componentId = $_instance->getRenderedChildComponentId('2X4Fz3B');
    $componentTag = $_instance->getRenderedChildComponentTagName('2X4Fz3B');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2X4Fz3B');
} else {
    $response = \Livewire\Livewire::mount('navigation-dropdown');
    $html = $response->html();
    $_instance->logRenderedChild('2X4Fz3B', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
			<?php endif; ?>
			<?php endif; ?>
            <!-- Page Heading -->
            
                
                    
                
            

            <!-- Page Content -->
            <main>
                <?php echo e($slot); ?>

            </main>
        </div>

        <?php echo $__env->yieldPushContent('modals'); ?>

        
    </body>
</html>
<?php /**PATH /var/www/simoneb/resources/views/layouts/app.blade.php ENDPATH**/ ?>